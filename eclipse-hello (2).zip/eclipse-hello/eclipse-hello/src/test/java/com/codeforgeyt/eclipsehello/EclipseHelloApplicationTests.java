package com.codeforgeyt.eclipsehello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EclipseHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
