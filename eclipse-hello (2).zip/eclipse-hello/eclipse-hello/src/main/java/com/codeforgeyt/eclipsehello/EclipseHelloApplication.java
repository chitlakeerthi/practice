package com.codeforgeyt.eclipsehello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EclipseHelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(EclipseHelloApplication.class, args);
		System.out.println("Hello World");
	}

}
